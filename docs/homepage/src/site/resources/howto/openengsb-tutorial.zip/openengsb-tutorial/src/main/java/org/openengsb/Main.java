package org.openengsb;

/*
 * This is a sample application application.
 */

public class Main {
  public static void main(String[] argv) {
    System.out.println("Hello World!");
  }
}
